"""
class AI():
  def fn(self,n):
    if n==1:
      return 1
    else:
      return self.fn(self,n-1)* n
  def fy(self,x,n):
    tt = self.fn(self,n)*2+x
    return tt

x = 10
n= 10
print ('fn({}) = {}'.format(n, AI.fn(AI,n)))
print ('fy(x,n) fy({},{}) = {}'.format(n,x,AI.fy(AI,x,n)))
"""

class AI():
  def __init__(self):
    self.n = 0
    self.x = 0
  def fn(self,n):
    if n==1:
      return 1
    else:
      return self.fn(self,n-1)* n
  def fy(self,x,n):
    tt = self.fn(self,n)*2+x
    return tt


print('AI.fy(AI,10,10)=',AI.fy(AI,10,10),"should be 7257610")

