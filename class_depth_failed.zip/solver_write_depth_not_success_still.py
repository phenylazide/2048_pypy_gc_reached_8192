import engine, random, curses
COLORS = {0:0,2:1,4:2,8:3,16:4,32:5,64:6,128:7,256:8,512:9,1024:10,2048:11,4096:12,8192:13,16384:13,32768:12,65536:12}


global field
#field = [[int(180/((3-x)**2*1.5+(3-y)**2))+1 if (x!=3 or y!=3) else 720 for y in range(4)] for x in range(4)]
#field = [[9, 11, 13, 14], [13, 19, 26, 31], [18, 33, 73, 121], [21, 46, 181, 720]]
field = [[0, 0, 0, 0], [1, 2, 3, 3], [2, 3, 7, 12], [2, 5, 18, 30]]
global b_field  ## blank field 
b_field = [[4,2,1,-1],
					[2,1,0,0],
					[1,1,0,-1],
					[-1,-2,-2,-4]]
global runs_power  ## according to blank spot, if blank spot less, runs heavily increased.
runs_power = [10+2**(10-n) if n<10 else 10 for n in range(16)]

global max_depth_dict  ## according to len(spots)
max_depth_dict = {0:7,1:7,2:6,3:6,
									4:6,5:5,6:5,7:4,
									8:4,9:4,10:4,11:4,
								12:3,13:3,14:3,15:3,16:3}

global max_runs_dict  ## according to len(spots)
max_runs_dict = {0:2000,1:1000,2:800,3:700,
								4:500,5:200,6:50,7:20,
								8:20,9:10,10:10,11:10,
								12:10,13:10,14:10,15:10,16:10}

dGame = engine.Engine()


def makeGame():
	"""
	Creates a new instance of a game
	"""
	game = engine.Engine()
	return game

def drawBoard(board, screen):
	"""
	Draws a given board on a given curses screen
	"""
	for row in enumerate(board):
		for item in enumerate(row[1]):
			screen.addstr(8+3*row[0], 40+6*item[0], str(item[1]), curses.color_pair(COLORS[item[1]]))
	screen.refresh()


def write_record(board,gc_eva_score,gameScore,blank_spots,move):
	f=open('record.txt','a')
	for row in enumerate(board):
		f.write('{} \n'.format(str(row[1])))
	f.write('gc_eva_score = {}, gameScore = {} \n'.format(gc_eva_score,gameScore))
	f.write('blank_spots = {} move = {} \n'.format(str(blank_spots),move))
	f.write('old_boards = {}\n new_boards = {} \n'.format(old_boards,new_boards))
	f.close()

def gc_draw_record_Board(board,screen,gc_eva_score,gameScore,blank_spots,move):
	write_record(board,gc_eva_score,gameScore,blank_spots,move)
	for row in enumerate(board):
		for item in enumerate(row[1]):
			screen.addstr(8+3*row[0], 40+6*item[0], str(item[1]), curses.color_pair(COLORS[item[1]]))
	screen.refresh()

def just_write_game(board,screen,gc_eva_score,gameScore,blank_spots,move):
	write_record(board,gc_eva_score,gameScore,blank_spots,move)


def copyBoard(board):
	newBoard = makeGame().board
	for row in enumerate(board):
		for item in enumerate(row[1]):
			newBoard[row[0]][item[0]] = item[1]
	return newBoard

class AI():  ##try class type, but failed
	#@staticmethod
	def __init__(self):
		self.board = [[0 for i in range(4)] for i in range(4)]
		self.first_board = [[0 for i in range(4)] for i in range(4)]
		#self.board = board
		self.firstMove = ''
		self.old_boards = [[[0 for i in range(4)] for i in range(4)] for i in range(11)]
		self.new_boards = [[[0 for i in range(4)] for i in range(4)] for i in range(11)]
		self.moveLists = [['d','r','l'] for i in range(11)]
		self.best_score = -9999
		self.Depth = 1
		self.maxDepth = 4
		self.death_Nu = 0
	#@staticmethod
	def gc_eva_firstmove(self, board, firstMove):
		self.board = board
		dGame.board = copyBoard(board)
		self.firstMove = firstMove
		dGame.makeMove(firstMove)
		first_board = dGame.board
		if dGame.gameOver():
			return (9999,-100)
		elif self.first_board == self.board:
			return (9999,-50)
		else:
			#maxDepth = max_depth_dict[len(AI.spots)]   ## highest is 7
			self.maxDepth = 6
			self.old_boards[1] = first_board
			result = self.search_in_depth(Depth)
			#print('first_board, firstMove', first_board,firstMove)
			#print('@gc_eva_firstmove****\n result =\n********\n',result)
			#f=open('gc_best_movelog.txt','a')
			#f.write('first_board = {}\n result = {}\n'.format(first_board,result))
			#f.write('maxDepth = {}\n'.format(maxDepth))
			#f.close
			return result
	@staticmethod
	def search_in_depth(self, Depth): 
		i = self.Depth                         ## i means the depth level, for short use i
		#moveLists[i] = up_movable(old_board)[1]
		moveList = self.moveLists[i]
		##print ('bestscore,death_Nu,maxDepth,Depth =',best_score,death_Nu,maxDepth,Depth)
		for j,_move in enumerate(moveList):
		#for j, _move in enumerate(['d','r','l']):
			dGame.board = old_boards[i]
			dGame.makeMove(_move)
			self.new_boards[i] = dGame.board   ## i.e   new_boards[i-1] = dGame.board
			del self.moveLists[i][j]    ## remove those moveLists that already done 
			if i < self.maxDepth:   ##if depth < maxDepth:     Depth  begin from i until max            
				if (AI.gameOver() or self.old_boards[i] == self.new_boards[i]):
					if _move == 'l':
						self.death_Nu += 1
						if i == 1:   ## means first layer, and deadend
							return (death_Nu,-50)
							#return (death_Nu,-50)    ## this means, the second step is deadend. 
														### may not happen, cause dealed during first step
						else:
							self.Depth -= 1
							return self.search_in_depth(Depth)
							## not reach max level, dead, need to back up to a up-level ?? or just terminated it??
				else:
					self.old_boards[i+1] = self.new_boards[i]
					self.Depth += 1
					return self.search_in_depth(Depth)

			else:   ## i == self.maxDepth:   # means last layer
				new_score = gc_eva_score(self.new_boards[i])
				#f=open('seach_result.log','a')
				#f.write('new_score = gc_eva_score(new_boards[i]) === {}, {}'.format(new_score,str(new_boards[i])))
				#f.close
				if new_score > self.best_score:
					self.best_score = new_score
				if (AI.gameOver() or self.old_boards[i] == self.new_boards[i]):
					if _move == moveList[-1]:
						death_Nu += 1  
						return (death_Nu,best_score)  ## if it's deadend, must also apply some punishment
				#else:
					#continue   ## no need to write it, would auto do the continue if not moveList[-1]
				            #if not last moveList continue search in same depth
					else:
						return (death_Nu,best_score)  ## and best_score should get high power if get to more deeplayer.
		 			## search down level

	
def up_movable(x):  #x is board, if fist line last two member exist, then up_movable is set True.
	#movable = False
	for i in range(3):
		if x[i][2]==0 or x[i][3]==0 or x[i][2]==x[i+1][2] or x[i][3]==x[i+1][3]:
			return (False,['d','r','l'])
	return (True,['d','r','l','u'])


def gc_eva_score(x):  #x is board ## right,down move is same, no difference. should apply this symmetry in scoring.
	order_scores = 0
	repeat_scores = 0
	blank_scores = 0
	combined_scores = 0
	average_board_score = 0
	for i in range(3,-1,-1):  # value is: 3,2,1
		for j in range(3,-1,-1):
			average_board_score += x[i][j]
	average_board_score = int(average_board_score/16)

	for i in range(3,-1,-1):  # value is: 3,2,1
		for j in range(3,-1,-1):
			order_scores += int(x[i][j]*field[i][j])+1
			if x[i][j] != 0 and i>0:
				for j1 in range(4):
					if x[i][j] == x[i-1][j1]:    
	## i.e.  compare above row
						repeat_scores += int(x[i][j]*(field[i][j]+field[i-1][j1]))*2*abs(j-j1)     ## apply heavy punished
                                   
			elif x[i][j] == 0:                    ## replation forces  
				blank_scores += int(average_board_score/4)*b_field[i][j]
## make more blank as many as possible, high power then just pull together, this will encourage merged
	combined_scores = order_scores - repeat_scores + blank_scores
	return combined_scores

def bestMove(game, runs):
	"""
	Returns the best move for a given board.
	Plays "runs" number of games for each possible move and calculates which move had best avg end score.
	"""
	average = 0
	bestScore = 0
	moveList = game.moveList

	for moveDir in moveList:
		average = 0
		for x in range(runs):   ## runs many times, get average
			result = runRandom(game.board, moveDir)
			average += result
		average = average/runs
		if average >= bestScore:
			bestScore = average
			move = moveDir
	return move

def gc_bestMove(game, runs): ## this is virtully running for searching
	"""
	Returns the best move for a given board.
	Plays "runs" number of games for each possible move and calculates which move had best avg end score.
	"""
	move_average = 0
	#old_gc_eva_score = gc_eva_score(game.board)
	gc_bestScore = -9999999
	#moveList = up_movable(game.board)[1]
	moveList = ['d','r','l',]
	move = 'u'
	wrong_move_sign_Nu = 1  ## similar as death??
	for moveDir in moveList:
		##print('for moveDir in moveList:',moveDir)
		move_average = 0
		for x in range(runs):
			result = AI.gc_eva_firstmove(AI,game.board, moveDir)
			move_average += result[1]
			#wrong_move_sign_Nu += result[0]
			if result <= 0:
				wrong_move_sign_Nu += 1

			if wrong_move_sign_Nu >50 and x>100 and (x/wrong_move_sign_Nu) < 2.5:  
			## control un-necessary runs, to break it early if found at 12 times
				#move_average=-10000*(x+1)
				break
		#average = average/(x+1)             ## here not runs,but x+1 because of break
		move_average = move_average/(x+1)
		#print('move_average,runs,moveDir = ',move_average,runs,moveDir)
		if move_average > gc_bestScore:  ### move_average dominate the scoring funcation
			#bestScore = average
			gc_bestScore = move_average
			move = moveDir
		"""
		f=open('gc_bestMove.log','a')
		for row in enumerate(game.board):
			f.write('{} \n'.format(str(row[1])))
		f.write('move_average,gc_bestScore,runs,moveDir = {},|{},|{} {}'.format(move_average,gc_bestScore,runs,moveDir))
		f.write('wrong_move_sign_Nu, x = {} , {}\n'.format(wrong_move_sign_Nu, x))
		f.close
		"""
	return move

def solveGame(runs, screen):
	"""
	AI that plays a game till the end given a number of runs to make per move

	"""
	mainGame = makeGame()
	moveList = mainGame.moveList
	isDynamic = False

	#If runs is set to dynamic, increase the number of runs as score increases
	if runs == 'Dynamic':
		isDynamic = True

	while True:
		if mainGame.gameOver():
			break

		if isDynamic:
			runs = int(1 + (0.01)*mainGame.score)

		if runs > 0:
			move = bestMove(mainGame, runs)
		else:
			move = random.choice(moveList)
			
		mainGame.makeMove(move)
		screen.clear()
		drawBoard(mainGame.board, screen)

	return(mainGame)


def gc_solveGame(runs, screen):
	"""
	improved scoring function not as total scores,but according the ordering and number repeaty

	"""
	mainGame = makeGame()
	moveList = mainGame.moveList
	isDynamic = False

	#If runs is set to dynamic, increase the number of runs as score increases
	if runs == 'Dynamic':
		isDynamic = True

	while True:
		if mainGame.gameOver():
			break

		if isDynamic:
			#runs = 10 + 3*3**int((15-len(mainGame.spots))/3)
			runs = max_depth_dict[len(mainGame.spots)]
		if runs > 0:
			move = gc_bestMove(mainGame,runs)
		else:
			move = gc_random.choice(moveList)
		mainGame.must_makeMove(move)
		screen.clear()
		gc_draw_record_Board(mainGame.board,screen,gc_eva_score(mainGame.board),mainGame.score,mainGame.spots,move)
		just_write_game(mainGame.board,screen,gc_eva_score(mainGame.board),mainGame.score,mainGame.spots,move)
	return(mainGame)

def no_curse_game(runs,screen):

	mainGame = makeGame()
	moveList = mainGame.moveList

	while True:
		if mainGame.gameOver():
			break
		move = gc_bestMove(mainGame,runs)
		mainGame.must_makeMove(move)
		just_write_game(mainGame.board,screen,gc_eva_score(mainGame.board),mainGame.score,mainGame.spots,move)
	return(mainGame)
